import { fork } from 'redux-saga/effects';

import { saga as list } from './page/list';


export default function* rootSaga() {
    yield fork(list.getProductListFlow);
    yield fork(list.getSearchFilterCondFlow);
}