import { combineReducers } from "redux";
import home from './page/home/reducer'
import list from './page/list/reducer'

// root    reducer 



export default combineReducers({
    home,
    list
});