import axios from 'axios';

export const getProductListApi = (url, params = {}) => axios({
    url, params
})
// getSearchFilterApi
export const getSearchFilterApi = (url, params = {}) => axios({
    url, params
})