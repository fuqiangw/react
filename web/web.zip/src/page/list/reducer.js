import { combineReducers } from "redux";
import * as actionType from './actionType';


function resolveGetProductList(state = {}, action){
    switch(action.type) {
        case actionType.RESOLVE_GET_PRODUCT_LIST:
        return action.payload.data;
        default: 
        return state
    }
}
function resolveGetFilterCond(state = {}, action){
    switch(action.type) {
        case actionType.RESOLVE_GET_SEARCH_FILTER_COND:
        return action.payload.data;
        default: 
        return state
    }
}
export default combineReducers({
    productList: resolveGetProductList,
    filterCond: resolveGetFilterCond,
});