import React from 'react';

class Effect extends React.Component {
  render() {
    return (
        <div>
            Effect(Effect)
        </div>
    );
  }
}

export default Effect;
